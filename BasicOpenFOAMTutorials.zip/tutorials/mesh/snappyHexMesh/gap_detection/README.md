Testcase for automatic gap refinement. The geometry is two nested boxes
with a single small pipe between them.

- 1 cell initial mesh
- consistent normal orientation of surface so
  specify a 'gapMode' to limit refinement only to
  gaps on the 'outside' of the surface
