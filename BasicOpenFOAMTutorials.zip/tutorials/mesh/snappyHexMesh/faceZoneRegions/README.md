Block (as cellZone) inside cylinder. Demonstrates naming faceZones
on outside of the cellZone according to surface name, surface region.
