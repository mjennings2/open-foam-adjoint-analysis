The experimental surface elevation data is taken from:

    Liu, P. L. F., Lin, P., Chang, K. A., & Sakakiyama, T. (1999).
    Numerical modeling of wave interaction with porous structures.
    Journal of waterway, port, coastal, and ocean engineering,
    125(6), 322-330.
    DOI:10.1061/(ASCE)0733-950X(1999)125:6(322)

Calibtration of porosity model is taken from:

    Jensen, B., Jacobsen, N. G., & Christensen, E. D. (2014).
    Investigations on the porous media equations and resistance
    coefficients for coastal structures.
    Coastal Engineering, 84, 56-72.
    DOI:10.1016/j.coastaleng.2013.11.004
