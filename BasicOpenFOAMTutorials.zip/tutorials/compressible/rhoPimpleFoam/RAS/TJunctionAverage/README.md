## Simple T-junction.

- Inlet on left, one outlet at bottom, one at top.
- To test multiple outlets.
- Enable debug.scanner/debug.parser for a verbose view of the parsing engine.
