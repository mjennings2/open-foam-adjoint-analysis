References:
    ERCOFTAC T3A 3% test-case

    Savill, A. M. (1993).
    Some recent progress in the turbulence modelling of by-pass transition.
    Near-wall turbulent flows, 829-848.

    Savill, A. M. (1996).
    One-point closures applied to transition.
    In Turbulence and transition modelling (pp. 233-268).
    Springer Netherlands.
