Steady flow over a 2D flat plate

This case is based on the zero pressure gradient flat plate test described
by the Langley Research Center Turbulence Modeling Resource provided at:

    https://turbmodels.larc.nasa.gov/flatplate.html

The Reynolds number based on the plate length is of Re_L = 5×10^6

The Allrun script applies a selection of tubulence models to a range of y+
meshes which for which graphs are created that compare the predictions
against the data from Weighardt.

For further information please visit:

    openfoam.com/documentation/cpp-guide/html/verification-validation-turbulent-flat-plate-zpg.html
