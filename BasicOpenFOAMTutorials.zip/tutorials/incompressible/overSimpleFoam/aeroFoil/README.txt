Steady state, steady mesh
-------------------------

aeroFoil_snappyHexMesh/
    For generating (3D) mesh for background

aeroFoil_overset/
    Extruding into 2D

background_snappyHexMesh/
    For generating (3D) mesh for background

background_overset/
    Combined mesh for running
