Transient, moving mesh
----------------------
Two turning rotors
