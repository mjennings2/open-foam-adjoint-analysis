Testcase for cyclicPeriodicAMI functionality. This case is adapted
from the oscillatingInletACMI2D testcase. Assumes cyclic behaviour
in y-direction; this cyclic transformation is used to extend the underlying
cyclicAMI such that the weights on either side add up to (at least) one.
