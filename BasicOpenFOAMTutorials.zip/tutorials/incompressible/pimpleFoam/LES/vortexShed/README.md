Summary
- Vortex street generated from flow over a sphere
- Acoustic pressure is calculated based on Curle's analogy
- noise utility is processes the acoustic pressure to obtain frequency information

Case detailis
- cylinder diameter: 0.04
- flow speed: 0.025
- kinematic viscosity: 1e-5
- Reynolds number based on cylinder diameter, Red = 100
- For this Red, St = 0.198(1 - 0.197/Red) = 0.159
- Shedding fequency, f = St*U/d = 0.1 Hz

Plotting the FFT of the pressure field shoud show a peak at the shedding
frequency
