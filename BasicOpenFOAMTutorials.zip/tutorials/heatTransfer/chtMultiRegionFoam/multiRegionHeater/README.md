- The 0/ field files contain nonsense patchFields.
  All interesting work is done using the changeDictionaryDicts.
- The uses region-specific decomposition for the heater.
  This can be useful when the solid region is relatively small and a
  normal decomposition would result in very few cells per process.
