Reference for the Duisburg Test Case (DTC):
Moctar, O. E., Shigunov, V., & Zorn, T. (2012).
Duisburg test case: Post-Panamax container ship for benchmarking.
Ship Technology Research, 59(3), 50-64.
DOI:10.1179/str.2012.59.3.004