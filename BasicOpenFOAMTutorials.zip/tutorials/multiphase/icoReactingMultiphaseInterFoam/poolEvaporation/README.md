kineticGasEvaporation model test case

Still evaporating pool with heat flux from bottom.

The theoretical area-averaged mass flux evaporating is 1.2e-4 Kg/s.
This averaged value is reached approximately at 110 secs.
